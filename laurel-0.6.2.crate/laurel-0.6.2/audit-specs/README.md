The tables in the _fields_ and _messages_ subdirectories have been
copied from the 
[Linux-audit documentation](https://github.com/linux-audit/audit-documentation)
repository.
