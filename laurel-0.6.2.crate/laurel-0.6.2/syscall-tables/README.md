The `*.h` files in this directory have been copied from the [Linux-audit userspace](https://github.com/linux-audit/audit-userspace) repository.
