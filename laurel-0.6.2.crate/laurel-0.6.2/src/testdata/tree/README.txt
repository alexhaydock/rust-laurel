This series of files represents audit logs from a single "apt-get
update" run. apt-get has been tagged by the Audit subsystem with the
"software_mgmt" key.
